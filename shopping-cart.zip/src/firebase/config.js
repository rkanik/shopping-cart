export default {
	apiKey: "AIzaSyB7oK78a6LPRzhBlZ-q0mCSF5-emWCG7S4",
	authDomain: "rkanik-me.firebaseapp.com",
	databaseURL: "https://rkanik-me.firebaseio.com",
	projectId: "rkanik-me",
	storageBucket: "rkanik-me.appspot.com",
	messagingSenderId: "49836700278",
	appId: "1:49836700278:web:fe2062f690688d5eee2557",
	measurementId: "G-8YMWBYFLS7"
};