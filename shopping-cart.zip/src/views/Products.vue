<template>
	<div class="products">
		<h4>This is products component</h4>
	</div>
</template>

<script>
export default {
	name: 'Products',

}
</script>

<style lang='scss' scoped>
	.products {
	}
</style>