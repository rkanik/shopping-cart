<template>
	<div class="security">
		<h4>This is security component</h4>
	</div>
</template>

<script>
export default {
	name: 'Security',

}
</script>

<style lang='scss' scoped>
	.security {
	}
</style>