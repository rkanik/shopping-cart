<template>
	<div class="me">
		<h4>This is me component</h4>
	</div>
</template>

<script>
export default {
	name: 'me',

}
</script>

<style lang='scss' scoped>
	.me {
	}
</style>