<template>
	<div class="cart">
		<h4>This is cart component</h4>
	</div>
</template>

<script>
export default {
	name: 'cart',

}
</script>

<style lang='scss' scoped>
	.cart {
	}
</style>