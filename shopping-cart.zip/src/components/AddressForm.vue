<template>
	<div class="address">
		<h4>This is address component</h4>
	</div>
</template>

<script>
export default {
	name: 'address',
	data: () => ({
		address: {
			
		}
	}),
}
</script>

<style lang='scss' scoped>
	.address {
	}
</style>