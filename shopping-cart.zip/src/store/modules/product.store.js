const initialState = {
	products: [
		{
			id: '2',
			slag: 'honor_watch_gs_pro_kan_b19s_silicone_strap_black',
			name: 'Honor Watch GS PRO KAN-B19S Coal Black',
			thumbnail: 'https://manom.ru/upload/iblock/0fd/0fdd6b7b16d251fd840f4ceae2923344.jpg',
			images: [
				'https://manom.ru/upload/iblock/0fd/0fdd6b7b16d251fd840f4ceae2923344.jpg',
				'https://manom.ru/upload/iblock/9d2/9d2737fe50add36c8f931cdf42c82e46.jpg',
				'https://manom.ru/upload/iblock/408/408378de5feded583aab6232455c85c9.jpg',
				'https://manom.ru/upload/iblock/dc0/dc0001566cbec25f655f4cb97d949db7.jpg',
			],
			oPrice: 300,
			sPrice: 265,
			currency: 'CAD'
		},
		{
			id: '1',
			slag: 'apple-iphone-11',
			name: 'Apple iPhone 11 128GB Purple (New Trim)',
			thumbnail: 'https://manom.ru/upload/resize_cache/iblock/5d9/350_350_1/5d961ada109a58b7dfddb559edd27c24.jpg',
			images: [
				'https://manom.ru/upload/resize_cache/iblock/5d9/350_350_1/5d961ada109a58b7dfddb559edd27c24.jpg',
				'https://manom.ru/upload/iblock/2f5/2f5569c50c556fc839fb52bf10406507.jpg',
				'https://manom.ru/upload/iblock/9bc/9bcd6d753346c79ac30b9154d6234b9d.jpg',
				'https://manom.ru/upload/iblock/3d6/3d65f0929d4e6e0c381182a704850293.jpg',
			],
			oPrice: 1038,
			sPrice: 1038,
			currency: 'CAD'
		},
		{
			id: '3',
			slag: 'plantronics_backbeat_pro_5100_chernye',
			name: 'Wireless Headphones Plantronics BackBeat PRO 5100 Black',
			thumbnail: 'https://manom.ru/upload/iblock/a6b/a6b80d6f44035b1c92840a081644c1d0.jpg',
			images: [
				'https://manom.ru/upload/iblock/a6b/a6b80d6f44035b1c92840a081644c1d0.jpg',
				'https://manom.ru/upload/iblock/df2/df26c5d26a08ab377aedc442bea870d5.jpg',
				'https://manom.ru/upload/iblock/d14/d14c2998548de191f54f5c63c494c0f2.jpg',
				'https://manom.ru/upload/iblock/d62/d6263e306b1a63c7d97977a4bb7b8928.jpg',
			],
			oPrice: 102,
			sPrice: 102,
			currency: 'CAD'
		},
		{
			id: '4',
			slag: 'huawei_mate_40_pro_8_256gb_noh_nx9_misticheskiy_serebristyy',
			name: 'Huawei Mate 40 Pro 8/256GB mystical silver',
			thumbnail: 'https://manom.ru/upload/iblock/979/97972ec8c741b3bf6e55395bc7d519da.jpg',
			images: [
				'https://manom.ru/upload/iblock/979/97972ec8c741b3bf6e55395bc7d519da.jpg',
				'https://manom.ru/upload/iblock/19a/19a1c9fdb2604c34a08c46df0c6e4945.jpg',
				'https://manom.ru/upload/iblock/19a/19a1c9fdb2604c34a08c46df0c6e4945.jpg',
				'https://manom.ru/upload/iblock/0a0/0a00aeb923ce3913941a8c05fbfb1128.jpg',
			],
			oPrice: 1572,
			sPrice: 1572,
			currency: 'CAD'
		}
	]
}

const state = { ...initialState }

const getters = {
	$products: ({ products }) => products
}

const mutations = {
	setProState: (state, payload) => {
		Object.keys(payload).forEach((key) => {
			state[key] = payload[key];
		});
		console.log('setProState', payload, state)
	},
	resetProState: state => {
		const newState = { ...initialState }
		Object
			.keys(newState)
			.forEach(key =>
				state[key] = newState[key]
			)
	}
}

const actions = {

}

export default {
	namespaced: true, actions,
	state, getters, mutations
}
